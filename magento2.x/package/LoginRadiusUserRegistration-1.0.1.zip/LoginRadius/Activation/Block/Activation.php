<?php
namespace LoginRadius\Activation\Block;
 
class Activation extends \Magento\Framework\View\Element\Template
{
	public function _prepareLayout()
	{
		return parent::_prepareLayout();
	}
}