require(['jquery', 'jquery/ui'], function ($) {
    $(document).ready(function () {
        $('#lractivation_activationhelp,#lractivation_activationhelp-head').hide();
    });
    
});