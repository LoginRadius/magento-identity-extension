require(['jquery', 'jquery/ui'], function ($) {
    // $(document).ready(function () {
    //     iefPageToggle();
    //     $("#lrauthentication_redirection_settings_enable_ief_page").change(function () {
    //         iefPageToggle();
    //     });
    // });
    
    // function iefPageToggle() {
    //     if ($('#lrauthentication_redirection_settings_enable_ief_page').val() == '1') {
    //         $('#lrauthentication_email_authentication_settings-state, #lrauthentication_phone_authentication_settings-state').parent().hide();
           
    //     } else {
    //         $('#lrauthentication_email_authentication_settings-state, #lrauthentication_phone_authentication_settings-state').parent().show();
           
    //     }
    // }
});