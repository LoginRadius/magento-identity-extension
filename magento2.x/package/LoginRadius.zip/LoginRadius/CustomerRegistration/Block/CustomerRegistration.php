<?php

namespace LoginRadius\CustomerRegistration\Block;

class CustomerRegistration extends \Magento\Framework\View\Element\Template {

    public function _prepareLayout() {
        return parent::_prepareLayout();
    }
}
