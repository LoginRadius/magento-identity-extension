<?php
namespace LoginRadius\SingleSignOn\Block;
 
class SingleSignOn extends \Magento\Framework\View\Element\Template
{
	public function _prepareLayout()
	{
		return parent::_prepareLayout();
	}
}