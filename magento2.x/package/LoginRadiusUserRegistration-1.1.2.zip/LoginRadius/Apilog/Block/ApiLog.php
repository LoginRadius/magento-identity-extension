<?php
namespace LoginRadius\Apilog\Block;

class Apilog extends \Magento\Framework\View\Element\Template
{
	public function _prepareLayout()
	{
		return parent::_prepareLayout();
	}
	
}