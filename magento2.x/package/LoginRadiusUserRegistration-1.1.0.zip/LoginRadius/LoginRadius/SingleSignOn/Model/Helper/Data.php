<?php

namespace LoginRadius\SingleSignOn\Model\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    public function __construct(\Magento\Framework\App\Helper\Context $context,
            \Magento\Customer\Model\CustomerFactory $customerFactory,
            \Magento\Framework\ObjectManagerInterface $objectManager) {
        $this->_customerFactory = $customerFactory;
        $this->_objectManager = $objectManager;
        parent::__construct($context);
    }

    public function getConfig($section, $config_path) {
        return $this->scopeConfig->getValue(
                        'lr' . $section . '/' . $config_path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    //Enable SSO Settings
    public function enableSinglesignon() {
        if($this->getConfig('customerregistration', 'redirection_settings/raas_enable') == '1'){
            return $this->getConfig('singlesignon', 'singlesignon/enabled');
        }else{
            return '';
        }        
    }

}
