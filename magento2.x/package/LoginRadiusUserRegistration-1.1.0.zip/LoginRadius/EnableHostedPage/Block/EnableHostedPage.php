<?php
namespace LoginRadius\EnableHostedPage\Block;
 
class EnableHostedPage extends \Magento\Framework\View\Element\Template
{
	public function _prepareLayout()
	{
		return parent::_prepareLayout();
	}
	
}